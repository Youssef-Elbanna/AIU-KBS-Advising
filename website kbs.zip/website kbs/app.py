from flask import Flask, render_template, request , redirect
import pandas as pd
import numpy as np
import os
from experta import *

app = Flask(__name__)
DATASET = "courses.csv"
POLICIES = "policies.csv"

# Define Fact model
class StudentProfile(Fact):
    pass

# Inference engine
class AdvisingEngine(KnowledgeEngine):
    def __init__(self, courses, student_data, policies_df):
        super().__init__()
        self.courses = courses
        self.student_data = student_data
        self.policies_df = policies_df
        self.recommended_courses = []
        self.total_credits = 0
        self.explanations = []
        self.credit_limit = self.get_dynamic_credit_limit()

    def get_dynamic_credit_limit(self):
        credit_policies = self.policies_df[self.policies_df["Category"].str.strip() == "Credit Limit"]
        rules = []

        for _, row in credit_policies.iterrows():
            condition = str(row["Condition"])
            max_credit = int(row["max"])
            match = re.findall(r'(\d+\.\d+)', condition)

            if "≥" in condition or ">=" in condition:
                rules.append((lambda cgpa, val=float(match[0]): cgpa >= val, max_credit))
            elif "≤" in condition and len(match) == 2:
                l, u = float(match[0]), float(match[1])
                rules.append((lambda cgpa, l=l, u=u: l <= cgpa < u, max_credit))
            elif "<" in condition:
                rules.append((lambda cgpa, val=float(match[0]): cgpa < val, max_credit))

        for rule, limit in rules:
            if rule(self.student_data["cgpa"]):
                return limit
        return 12  # Default fallback

    @Rule(StudentProfile())
    def recommend_courses(self):
        already_added = set()
        passed = [c.strip() for c in self.student_data["passed_courses"]]
        failed = [c.strip() for c in self.student_data["failed_courses"]]

        # Step 1: Prioritize failed courses
        for course in self.courses:
            code = str(course["Course Code"]).strip()
            prereqs = [p.strip() for p in str(course["Prerequisites"]).split(",") if p.strip()]
            offered = str(course["Semester Offered"]).strip().upper()
            credits = int(course["Credit Hours"])

            if code not in failed:
                continue
            if code in passed:
                self.explanations.append(f"{code} is not recommended because it was already passed.")
                continue
            if self.student_data["semester"].upper() not in offered and offered != "BOTH":
                self.explanations.append(f"{code} is unavailable this semester.")
                continue
            if any(pr not in passed for pr in prereqs):
                self.explanations.append(f"{code} is not recommended due to unmet prerequisite(s): {', '.join([pr for pr in prereqs if pr not in passed])}.")
                continue
            if self.total_credits + credits > self.credit_limit:
                self.explanations.append(f"{code} is not added because it would exceed the credit limit.")
                continue
            self.recommended_courses.append(course)
            already_added.add(code)
            self.total_credits += credits
            self.explanations.append(f"{code} is prioritized because you failed it previously and met its prerequisites.")

        # Recommend other eligible courses
        for course in self.courses:
            code = str(course["Course Code"]).strip()
            name = str(course["Course Name"]).strip()
            offered = str(course["Semester Offered"]).strip().upper()
            prereqs = [p.strip() for p in str(course["Prerequisites"]).split(",") if p.strip()]
            coreqs = [c.strip() for c in str(course["Co-requisites"]).split(",") if c.strip()]
            credits = int(course["Credit Hours"])

            if code in passed or code in already_added:
                continue
            if self.student_data["semester"].upper() not in offered and offered != "BOTH":
                self.explanations.append(f"{code} is not offered in the {self.student_data['semester']} semester.")
                continue
            if any(pr not in passed for pr in prereqs):
                self.explanations.append(f"{code} is not recommended due to unmet prerequisite(s): {', '.join([pr for pr in prereqs if pr not in passed])}.")
                continue
            if any(cr not in passed and cr not in [c["Course Code"].strip() for c in self.recommended_courses] for cr in coreqs):
                self.explanations.append(f"{code} is not recommended due to unmet co-requisite(s): {', '.join([cr for cr in coreqs if cr not in passed])}.")
                continue
            if self.total_credits + credits > self.credit_limit:
                self.explanations.append(f"{code} is not added because it would exceed the credit limit.")
                continue
            self.recommended_courses.append(course)
            already_added.add(code)
            self.total_credits += credits
            if prereqs:
                self.explanations.append(f"{code} is recommended because you passed {', '.join(prereqs)}, its prerequisite(s).")
            else:
                self.explanations.append(f"{code} is recommended because it has no prerequisites.")

def load_data():
    if not os.path.exists(DATASET):
        return pd.DataFrame(columns=[
            "Course Code", "Course Name", "Description", "Prerequisites",
            "Co-requisites", "Credit Hours", "Semester Offered"
        ])
    df = pd.read_csv(DATASET)
    # Replace NaN values with empty strings for string columns
    string_columns = ["Course Name", "Description", "Prerequisites", "Co-requisites", "Semester Offered"]
    df[string_columns] = df[string_columns].fillna('')
    # Replace NaN values with 0 for numeric columns (Credit Hours)
    df["Credit Hours"] = df["Credit Hours"].fillna(0)
    return df

def load_policies():
    if not os.path.exists(POLICIES):
        return pd.DataFrame(columns=["Category", "Condition", "max"])
    return pd.read_csv(POLICIES).fillna("")

def save_data(df):
    df.to_csv(DATASET, index=False)

def validate_course(codes_string, existing_codes):
    if not codes_string:
        return []
    codes = [c.strip() for c in codes_string.split(",") if c.strip()]
    return [c for c in codes if c not in existing_codes]

@app.route('/')
def home():
    return render_template('HomePage.html')

@app.route('/recommend', methods=['GET', 'POST'])
def recommend():
    courses_df = load_data()
    policies_df = load_policies()
    all_courses = courses_df.to_dict(orient="records")

    if request.method == 'POST':
        # Get form data
        cgpa = float(request.form['cgpa'])
        semester = request.form['semester']
        passed_courses = request.form.getlist('passed_courses')
        failed_courses = request.form.getlist('failed_courses')

        # Validate CGPA
        if cgpa < 0 or cgpa > 4:
            return render_template('recommend.html', 
                                 error="CGPA must be between 0.0 and 4.0",
                                 courses=all_courses)

        # Prepare student input
        student_input = {
            "cgpa": cgpa,
            "semester": semester.upper(),
            "passed_courses": passed_courses,
            "failed_courses": failed_courses
        }

        # Run recommendation engine
        engine = AdvisingEngine(all_courses, student_input, policies_df)
        engine.reset()
        engine.declare(StudentProfile(**student_input))
        engine.run()

        # Prepare results
        recommended_df = pd.DataFrame(engine.recommended_courses)[["Course Code", "Course Name", "Credit Hours"]]
        if not recommended_df.empty:
            recommended_df["Credit Hours"] = recommended_df["Credit Hours"].astype(int)
            total_credits = recommended_df["Credit Hours"].sum()
            recommendations = recommended_df.to_dict('records')
        else:
            recommendations = []
            total_credits = 0

        return render_template('recommend.html',
                             recommendations=recommendations,
                             total_credits=total_credits,
                             explanations=engine.explanations,
                             courses=all_courses,
                             cgpa=cgpa,
                             semester=semester,
                             passed_courses=passed_courses,
                             failed_courses=failed_courses)

    # GET request - show empty form
    return render_template('recommend.html', courses=all_courses)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        if request.form['username'] == 'admin' and request.form['password'] == 'admin1234':
             return redirect('/admin')
        else:
            return render_template('login.html', error="Invalid credentials")
    return render_template('login.html')

@app.route("/admin", methods=["GET", "POST"])
def manage_courses():
    df = load_data()
    message = ""
    error = ""
    selected_action = request.form.get("action", "View Courses")
    selected_course = None

    if request.method == "POST":
        if selected_action == "Add Course":
            code = request.form.get("code", "").strip().upper()
            name = request.form.get("name", "")
            desc = request.form.get("desc", "")
            prereq = request.form.get("prereq", "").strip().upper()
            coreq = request.form.get("coreq", "").strip().upper()
            hours = request.form.get("hours", "0")
            semester = request.form.get("semester", "").strip().upper()

            try:
                hours = int(hours)
            except ValueError:
                hours = -1

            existing_codes = df["Course Code"].tolist()
            invalid_prereq = validate_course(prereq, existing_codes)
            invalid_coreq = validate_course(coreq, existing_codes)

            if not code or not name or not desc or not semester:
                error = "All fields are required."
            elif code in existing_codes:
                error = "Course code already exists."
            elif hours < 0:
                error = "Credit hours must be a positive number."
            elif invalid_prereq or invalid_coreq:
                error = f"Invalid prerequisites: {', '.join(invalid_prereq)}" if invalid_prereq else ""
                error += f" Invalid co-requisites: {', '.join(invalid_coreq)}" if invalid_coreq else ""
            else:
                df.loc[len(df)] = {
                    "Course Code": code,
                    "Course Name": name,
                    "Description": desc,
                    "Prerequisites": prereq,
                    "Co-requisites": coreq,
                    "Credit Hours": int(hours),
                    "Semester Offered": semester
                }
                save_data(df)
                message = "Course added successfully!"

        elif selected_action in ["Edit Course", "Delete Course"]:
            selected_code = request.form.get("selected_code")
            if selected_code:
                # Get the course and replace NaN/None values
                selected_course = df[df["Course Code"] == selected_code].iloc[0].replace({pd.NA: None, np.nan: None}).to_dict()
                
                # Ensure all fields have proper default values
                selected_course = {
                    "Course Code": selected_course.get("Course Code", ""),
                    "Course Name": selected_course.get("Course Name", ""),
                    "Description": selected_course.get("Description", ""),
                    "Prerequisites": selected_course.get("Prerequisites", ""),
                    "Co-requisites": selected_course.get("Co-requisites", ""),
                    "Credit Hours": selected_course.get("Credit Hours", 0),
                    "Semester Offered": selected_course.get("Semester Offered", "")
                }
                
                if selected_action == "Edit Course":
                    name = request.form.get("name", selected_course["Course Name"])
                    desc = request.form.get("desc", selected_course["Description"])
                    prereq = request.form.get("prereq", selected_course["Prerequisites"]).strip().upper()
                    coreq = request.form.get("coreq", selected_course["Co-requisites"]).strip().upper()
                    semester = request.form.get("semester", selected_course["Semester Offered"]).strip().upper()
                    try:
                        hours = int(request.form.get("hours", selected_course["Credit Hours"]))
                    except ValueError:
                        hours = -1

                    existing_codes = df["Course Code"].tolist()
                    existing_codes.remove(selected_code)
                    invalid_prereq = validate_course(prereq, existing_codes)
                    invalid_coreq = validate_course(coreq, existing_codes)

                    if hours < 0:
                        error = "Credit hours must be a positive number."
                    elif invalid_prereq or invalid_coreq:
                        error = f"Invalid prerequisites: {', '.join(invalid_prereq)}" if invalid_prereq else ""
                        error += f" Invalid co-requisites: {', '.join(invalid_coreq)}" if invalid_coreq else ""
                    else:
                        df.loc[df["Course Code"] == selected_code, [
                            "Course Name", "Description", "Prerequisites",
                            "Co-requisites", "Credit Hours", "Semester Offered"
                        ]] = [name, desc, prereq, coreq, int(hours), semester]
                        save_data(df)
                        message = "Course updated successfully!"
                        # Reload the selected course with updated data
                        selected_course = df[df["Course Code"] == selected_code].iloc[0].replace({pd.NA: None, np.nan: None}).to_dict()
                        selected_course = {
                            k: v if v is not None and not pd.isna(v) else "" 
                            for k, v in selected_course.items()
                        }

                elif selected_action == "Delete Course":
                    prereq_course = df["Prerequisites"].astype(str).str.contains(rf'\b{selected_code}\b').any()
                    coreq_course = df["Co-requisites"].astype(str).str.contains(rf'\b{selected_code}\b').any()
                    if prereq_course or coreq_course:
                        error = f"Cannot delete course '{selected_code}' because it is used as a prerequisite or co-requisite."
                    else:
                        df = df[df["Course Code"] != selected_code]
                        save_data(df)
                        message = f"Course '{selected_code}' deleted."
                        selected_course = None  # Clear the selected course after deletion

    df = load_data()  # Reload after any update
    return render_template("editor.html", df=df, action=selected_action, 
                         message=message, error=error, selected_course=selected_course)

if __name__ == "__main__":
    app.run(debug=True)